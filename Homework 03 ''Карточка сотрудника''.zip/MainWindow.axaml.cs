using Avalonia.Controls;

namespace Homework2;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}