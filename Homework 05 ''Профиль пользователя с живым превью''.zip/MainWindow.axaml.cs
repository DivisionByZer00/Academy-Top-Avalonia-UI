using Avalonia.Controls;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Homework5;


public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        
        DataContext = new ProfileViewModel();
    }
}


public class ProfileViewModel : INotifyPropertyChanged
{
    private string _fullName = "";
    private string _selectedRole = "�����������";
    private string _email = "";
    private string _phone = "";
    private decimal _experienceYears = 0;
    private bool _isSubscribed;

    public string FullName
    {
        get => _fullName;
        set { _fullName = value; OnPropertyChanged(); }
    }

    public string SelectedRole
    {
        get => _selectedRole;
        set
        {
            _selectedRole = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(SummaryLine)); 
        }
    }

    public string Email
    {
        get => _email;
        set
        {
            _email = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(EmailWarning)); 
        }
    }

    public string Phone
    {
        get => _phone;
        set { _phone = value; OnPropertyChanged(); }
    }

    public decimal ExperienceYears
    {
        get => _experienceYears;
        set
        {
            _experienceYears = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(SummaryLine)); 
        }
    }

    public bool IsSubscribed
    {
        get => _isSubscribed;
        set { _isSubscribed = value; OnPropertyChanged(); }
    }

    

    public string SummaryLine => $"{SelectedRole}, ����: {ExperienceYears} ���";

    public string EmailWarning => string.IsNullOrWhiteSpace(Email) ? "Email �� ������" : "";

   
    public event PropertyChangedEventHandler? PropertyChanged;

    protected void OnPropertyChanged([CallerMemberName] string? propertyName = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}