using Avalonia.Controls;
using Avalonia.Interactivity;

namespace Homework1_AboutMe;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }

    private void ShowSecret_Click(object sender, RoutedEventArgs e)
    {
        SecretText.IsVisible = true;
    }

    private void Exit_Click(object sender, RoutedEventArgs e)
    {
        this.Close();
    }
}