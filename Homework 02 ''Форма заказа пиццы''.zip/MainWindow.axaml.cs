using Avalonia.Animation;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Interactivity;

namespace Homework1_AboutMe;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }


    public void UpdatePrice(object sender, RoutedEventArgs e)
    {
        
        if (PriceText == null) return;

        int price = 0;


        if (SmallRadio.IsChecked == true) price += 300;
        else if (MediumRadio.IsChecked == true) price += 500;

    
        if (CheeseCheck.IsChecked == true) price += 50;
        if (BaconCheck.IsChecked == true) price += 70;

        int count = (int)(Quantity.Value ?? 1);

        int total = price * count;

        PriceText.Text = $"�����: {total} ���.";
    }

    private void Order_Click(object? sender, RoutedEventArgs e)
    {
 
        if (string.IsNullOrWhiteSpace(NameBox.Text) || string.IsNullOrWhiteSpace(PhoneBox.Text))
        {
            Clue.Text = "������� ��� � �������";
            Clue.IsVisible = true;
            return;
        }

        Clue.Text = "����� ��������";
        Clue.IsVisible = true;
    }
}